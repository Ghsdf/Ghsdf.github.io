import React, { Component } from 'react'

export default class StuPub extends Component {
  render() {
    return (
      <div>学员录入</div>
    )
  }
}
