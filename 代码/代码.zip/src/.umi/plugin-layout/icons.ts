// @ts-nocheck

  import AreaChartOutlined from '@ant-design/icons/es/icons/AreaChartOutlined';
import GitlabOutlined from '@ant-design/icons/es/icons/GitlabOutlined';
import AliwangwangOutlined from '@ant-design/icons/es/icons/AliwangwangOutlined';
import WindowsOutlined from '@ant-design/icons/es/icons/WindowsOutlined';
import RadarChartOutlined from '@ant-design/icons/es/icons/RadarChartOutlined';
import CodeSandboxOutlined from '@ant-design/icons/es/icons/CodeSandboxOutlined';
import HeatMapOutlined from '@ant-design/icons/es/icons/HeatMapOutlined';
import SettingOutlined from '@ant-design/icons/es/icons/SettingOutlined'
  export default {
    AreaChartOutlined,
GitlabOutlined,
AliwangwangOutlined,
WindowsOutlined,
RadarChartOutlined,
CodeSandboxOutlined,
HeatMapOutlined,
SettingOutlined
  }