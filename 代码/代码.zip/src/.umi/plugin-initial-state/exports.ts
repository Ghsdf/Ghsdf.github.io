// @ts-nocheck

// @ts-ignore
import { InitialState as InitialStateType } from '../plugin-initial-state\models\initialState';

export type InitialState = InitialStateType;
export const __PLUGIN_INITIAL_STATE = 1;
