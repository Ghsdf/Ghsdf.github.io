// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'D:/2107H5/React（项目实战）/umi3-project/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": require('D:/2107H5/React（项目实战）/umi3-project/src/.umi/plugin-layout/Layout.tsx').default,
    "routes": [
      {
        "path": "/login",
        "component": require('@/pages/login/index').default,
        "name": "登录",
        "layout": false,
        "hideInMenu": true,
        "exact": true
      },
      {
        "path": "/",
        "component": require('@/pages/index').default,
        "name": "数据统计",
        "hideInMenu": true,
        "exact": true
      },
      {
        "path": "/dashboard",
        "component": require('@/pages/dashboard/index').default,
        "name": "数据统计",
        "icon": "AreaChartOutlined",
        "access": "isRoot",
        "exact": true
      },
      {
        "path": "/test",
        "component": require('@/pages/test/index').default,
        "name": "测试",
        "icon": "GitlabOutlined",
        "hideInMenu": true,
        "exact": true
      },
      {
        "path": "/stu",
        "name": "Mock使用",
        "icon": "AliwangwangOutlined",
        "routes": [
          {
            "path": "/stu/list",
            "component": require('@/pages/stu/list').default,
            "name": "学员列表",
            "exact": true
          },
          {
            "path": "/stu/pub",
            "component": require('@/pages/stu/pub').default,
            "name": "学员录入",
            "exact": true
          }
        ]
      },
      {
        "path": "/cate",
        "name": "分类管理",
        "icon": "WindowsOutlined",
        "access": "isAdmin",
        "routes": [
          {
            "path": "/cate/list",
            "component": require('@/pages/category/catelist').default,
            "name": "分类列表",
            "access": "isAdmin",
            "exact": true
          },
          {
            "path": "/cate/pub",
            "component": require('@/pages/category/catepub').default,
            "name": "分类发布",
            "access": "unAdmin",
            "exact": true
          }
        ]
      },
      {
        "path": "/banner",
        "name": "轮播管理",
        "icon": "RadarChartOutlined",
        "access": "isAdmin",
        "routes": [
          {
            "path": "/banner/list",
            "component": require('@/pages/banner/list').default,
            "name": "轮播列表",
            "exact": true
          },
          {
            "path": "/banner/pub",
            "component": require('@/pages/banner/pub').default,
            "name": "轮播发布",
            "exact": true
          },
          {
            "path": "/banner/edit",
            "component": require('@/pages/banner/edit').default,
            "name": "轮播编辑",
            "hideInMenu": true,
            "exact": true
          }
        ]
      },
      {
        "path": "/goods",
        "name": "商品管理",
        "icon": "CodeSandboxOutlined",
        "access": "isAdmin",
        "routes": [
          {
            "path": "/goods/list",
            "component": require('@/pages/goods/list').default,
            "name": "商品列表",
            "exact": true
          },
          {
            "path": "/goods/pub",
            "component": require('@/pages/goods/pub').default,
            "name": "商品发布",
            "exact": true
          }
        ]
      },
      {
        "path": "/dva",
        "name": "状态管理",
        "icon": "CodeSandboxOutlined",
        "routes": [
          {
            "path": "/dva/a",
            "component": require('@/pages/testdva/CompA').default,
            "name": "A组件",
            "exact": true
          },
          {
            "path": "/dva/b",
            "component": require('@/pages/testdva/CompB').default,
            "name": "B组件",
            "exact": true
          },
          {
            "path": "/dva/notice",
            "component": require('@/pages/testdva/Notice').default,
            "name": "消息中心",
            "exact": true
          }
        ]
      },
      {
        "path": "/area",
        "name": "配送范围",
        "component": require('@/pages/area').default,
        "icon": "HeatMapOutlined",
        "access": "isRoot",
        "exact": true
      },
      {
        "path": "/sys",
        "name": "系统设置",
        "icon": "SettingOutlined",
        "access": "isRoot",
        "routes": [
          {
            "path": "/sys/role",
            "component": require('@/pages/system/RoleManager').default,
            "name": "角色管理",
            "exact": true
          },
          {
            "path": "/sys/user",
            "component": require('@/pages/system/UserManager').default,
            "name": "账号管理",
            "exact": true
          }
        ]
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
