// @ts-nocheck
import { Plugin } from 'D:/2107H5/React（项目实战）/umi3-project/node_modules/umi/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','dva','getInitialState','initialStateConfig','layout','layoutActionRef','request',],
});

export { plugin };
